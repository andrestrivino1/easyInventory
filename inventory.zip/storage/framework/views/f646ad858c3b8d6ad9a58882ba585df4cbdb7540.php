<?php $__env->startSection('content'); ?>
<style>
    body .form-bg {
        font-family: Arial, sans-serif;
        background: #eef2f7;
        display: flex;
        justify-content: center;
        padding-top: 40px;
        padding-bottom: 40px;
        min-height: 87vh;
    }
    .form-container {
        background: white;
        width: 600px;
        max-width: 95%;
        padding: 30px;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.12);
        margin: auto;
    }
    .form-container h2 {
        margin-top: 0;
        font-size: 20px;
        color: #222;
        margin-bottom: 20px;
        font-weight: 700;
    }
    .form-group {
        margin-bottom: 18px;
    }
    .form-container label {
        display: block;
        margin-bottom: 6px;
        font-weight: bold;
        color: #333;
        text-align: left;
        font-size: 14px;
    }
    .form-container input,
    .form-container select {
        display: block;
        width: 100%;
        padding: 10px 16px;
        border: 1px solid #ccc;
        border-radius: 6px;
        font-size: 14px;
        background: #f8fafc;
        transition: box-shadow .15s, border-color .15s;
        box-sizing: border-box;
    }
    .form-container input:focus,
    .form-container select:focus {
        border-color: #4a8af4;
        outline: none;
        box-shadow: 0 0 4px rgba(74,138,244,0.14);
        background: #fff;
    }
    .form-container input[type="file"] {
        padding: 8px;
        background: white;
    }
    .file-link {
        display: inline-block;
        margin-top: 6px;
        padding: 6px 12px;
        background: #e3f2fd;
        color: #1565c0;
        border-radius: 4px;
        text-decoration: none;
        font-size: 13px;
        font-weight: 500;
    }
    .file-link:hover {
        background: #bbdefb;
    }
    .actions {
        display: flex;
        justify-content: space-between;
        margin-top: 20px;
    }
    .btn-cancel {
        background: transparent;
        border: none;
        color: #4a8af4;
        font-size: 15px;
        cursor: pointer;
        text-decoration: underline;
        font-weight: 500;
    }
    .btn-save {
        background: #4a8af4;
        color: white;
        border: none;
        padding: 10px 24px;
        border-radius: 6px;
        cursor: pointer;
        font-weight: bold;
        font-size: 15px;
    }
    .btn-save:hover {
        background: #2f6fe0;
    }
    .invalid-feedback {
        color: #d60000;
        font-size: 13px;
        margin-top: 4px;
        text-align: left;
    }
</style>
<?php if($errors->any()): ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>Swal.fire({icon:'error',title:'Error',text:'<?php echo e($errors->first()); ?>',toast:true,position:'top-end',showConfirmButton:false,timer:3500})</script>
<?php endif; ?>
<div class="form-bg">
    <div class="form-container">
        <h2>Editar Importación</h2>
        <form action="<?php echo e(route('imports.update', $import->id)); ?>" method="POST" enctype="multipart/form-data" autocomplete="off">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label for="product_name">Nombre del producto *</label>
                <input type="text" name="product_name" id="product_name" class="<?php $__errorArgs = ['product_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('product_name', $import->product_name)); ?>" required />
                <?php $__errorArgs = ['product_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="origin">Origen *</label>
                <input type="text" name="origin" id="origin" class="<?php $__errorArgs = ['origin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('origin', $import->origin)); ?>" placeholder="Ej: China, Estados Unidos..." required />
                <?php $__errorArgs = ['origin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label>Destino</label>
                <input type="text" value="Colombia" class="form-control" disabled style="background: #e9ecef; cursor: not-allowed;" />
                <small style="color: #666; font-size: 12px;">El destino siempre es Colombia</small>
            </div>

            <div class="form-group">
                <label for="departure_date">Fecha de salida *</label>
                <input type="date" name="departure_date" id="departure_date" class="<?php $__errorArgs = ['departure_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('departure_date', $import->departure_date)); ?>" required />
                <?php $__errorArgs = ['departure_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="arrival_date">Fecha estimada de llegada *</label>
                <input type="date" name="arrival_date" id="arrival_date" class="<?php $__errorArgs = ['arrival_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('arrival_date', $import->arrival_date)); ?>" required />
                <?php $__errorArgs = ['arrival_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label>Contenedores *</label>
                <div id="containers-container">
                    <?php if($import->containers && $import->containers->count() > 0): ?>
                        <?php $__currentLoopData = $import->containers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $container): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="container-item" data-container-id="<?php echo e($container->id); ?>" style="border: 1px solid #ddd; border-radius: 8px; padding: 15px; margin-bottom: 15px; background: #f9f9f9;">
                                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                                    <strong style="color: #333;">Contenedor #<?php echo e($index + 1); ?></strong>
                                    <button type="button" class="btn-remove-container" style="background: #dc3545; color: white; border: none; padding: 4px 10px; border-radius: 4px; cursor: pointer; font-size: 12px;">Eliminar</button>
                                </div>
                                <input type="hidden" name="containers[<?php echo e($index); ?>][id]" value="<?php echo e($container->id); ?>">
                                <div class="form-group" style="margin-bottom: 12px;">
                                    <label style="font-size: 13px; margin-bottom: 4px;">Referencia *</label>
                                    <input type="text" name="containers[<?php echo e($index); ?>][reference]" class="form-control" style="padding: 8px 12px; font-size: 14px;" value="<?php echo e(old('containers.'.$index.'.reference', $container->reference)); ?>" required />
                                </div>
                                <div class="form-group" style="margin-bottom: 12px;">
                                    <label style="font-size: 13px; margin-bottom: 4px;">PDF</label>
                                    <?php if($container->pdf_path): ?>
                                        <div><a href="<?php echo e(route('imports.download', [$import->id, 'container_'.$container->id.'_pdf'])); ?>" class="file-link" target="_blank"><i class="bi bi-file-pdf me-1"></i>Ver PDF actual</a></div>
                                    <?php endif; ?>
                                    <input type="file" name="containers[<?php echo e($index); ?>][pdf]" class="form-control" style="padding: 6px; font-size: 13px; margin-top: 8px;" accept="application/pdf" />
                                </div>
                                <div class="form-group" style="margin-bottom: 0;">
                                    <label style="font-size: 13px; margin-bottom: 4px;">Imágenes</label>
                                    <?php if($container->images): ?>
                                        <?php $__currentLoopData = $container->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imgIndex => $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div style="margin-bottom: 4px;"><a href="<?php echo e(route('imports.download', [$import->id, 'container_'.$container->id.'_image_'.$imgIndex])); ?>" class="file-link" target="_blank"><i class="bi bi-image me-1"></i>Ver Imagen <?php echo e($imgIndex+1); ?></a></div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    <input type="file" name="containers[<?php echo e($index); ?>][images][]" class="form-control" style="padding: 6px; font-size: 13px; margin-top: 8px;" accept="image/png,image/jpeg" multiple />
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div class="container-item" style="border: 1px solid #ddd; border-radius: 8px; padding: 15px; margin-bottom: 15px; background: #f9f9f9;">
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                                <strong style="color: #333;">Contenedor #1</strong>
                                <button type="button" class="btn-remove-container" style="background: #dc3545; color: white; border: none; padding: 4px 10px; border-radius: 4px; cursor: pointer; font-size: 12px; display: none;">Eliminar</button>
                            </div>
                            <div class="form-group" style="margin-bottom: 12px;">
                                <label style="font-size: 13px; margin-bottom: 4px;">Referencia *</label>
                                <input type="text" name="containers[0][reference]" class="form-control" style="padding: 8px 12px; font-size: 14px;" required />
                            </div>
                            <div class="form-group" style="margin-bottom: 12px;">
                                <label style="font-size: 13px; margin-bottom: 4px;">PDF</label>
                                <input type="file" name="containers[0][pdf]" class="form-control" style="padding: 6px; font-size: 13px;" accept="application/pdf" />
                            </div>
                            <div class="form-group" style="margin-bottom: 0;">
                                <label style="font-size: 13px; margin-bottom: 4px;">Imágenes</label>
                                <input type="file" name="containers[0][images][]" class="form-control" style="padding: 6px; font-size: 13px;" accept="image/png,image/jpeg" multiple />
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <button type="button" id="add-container-btn" style="background: #28a745; color: white; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer; font-size: 14px; font-weight: 500;">
                    <i class="bi bi-plus-circle me-1"></i>Agregar Contenedor
                </button>
                <?php $__errorArgs = ['containers'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="proforma_pdf">Proforma Invoice (PDF)</label>
                <?php if($import->proforma_pdf): ?>
                    <div><a href="<?php echo e(route('imports.view', [$import->id, 'proforma_pdf'])); ?>" class="file-link" target="_blank"><i class="bi bi-file-pdf me-1"></i>Ver PDF actual</a></div>
                <?php endif; ?>
                <input type="file" name="proforma_pdf" id="proforma_pdf" class="<?php $__errorArgs = ['proforma_pdf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" accept="application/pdf" style="margin-top: 8px;" />
                <?php $__errorArgs = ['proforma_pdf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="proforma_invoice_low_pdf">Proforma Invoice Low (PDF)</label>
                <?php if($import->proforma_invoice_low_pdf): ?>
                    <div><a href="<?php echo e(route('imports.view', [$import->id, 'proforma_invoice_low_pdf'])); ?>" class="file-link" target="_blank"><i class="bi bi-file-pdf me-1"></i>Ver PDF actual</a></div>
                <?php endif; ?>
                <input type="file" name="proforma_invoice_low_pdf" id="proforma_invoice_low_pdf" class="<?php $__errorArgs = ['proforma_invoice_low_pdf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" accept="application/pdf" style="margin-top: 8px;" />
                <?php $__errorArgs = ['proforma_invoice_low_pdf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="invoice_pdf">Commercial Invoice (PDF)</label>
                <?php if($import->invoice_pdf): ?>
                    <div><a href="<?php echo e(route('imports.view', [$import->id, 'invoice_pdf'])); ?>" class="file-link" target="_blank"><i class="bi bi-file-pdf me-1"></i>Ver PDF actual</a></div>
                <?php endif; ?>
                <input type="file" name="invoice_pdf" id="invoice_pdf" class="<?php $__errorArgs = ['invoice_pdf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" accept="application/pdf" style="margin-top: 8px;" />
                <?php $__errorArgs = ['invoice_pdf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="commercial_invoice_low_pdf">Commercial Invoice Low (PDF)</label>
                <?php if($import->commercial_invoice_low_pdf): ?>
                    <div><a href="<?php echo e(route('imports.view', [$import->id, 'commercial_invoice_low_pdf'])); ?>" class="file-link" target="_blank"><i class="bi bi-file-pdf me-1"></i>Ver PDF actual</a></div>
                <?php endif; ?>
                <input type="file" name="commercial_invoice_low_pdf" id="commercial_invoice_low_pdf" class="<?php $__errorArgs = ['commercial_invoice_low_pdf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" accept="application/pdf" style="margin-top: 8px;" />
                <?php $__errorArgs = ['commercial_invoice_low_pdf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="packing_list_pdf">Packing List (PDF)</label>
                <?php if($import->packing_list_pdf): ?>
                    <div><a href="<?php echo e(route('imports.view', [$import->id, 'packing_list_pdf'])); ?>" class="file-link" target="_blank"><i class="bi bi-file-pdf me-1"></i>Ver PDF actual</a></div>
                <?php endif; ?>
                <input type="file" name="packing_list_pdf" id="packing_list_pdf" class="<?php $__errorArgs = ['packing_list_pdf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" accept="application/pdf" style="margin-top: 8px;" />
                <?php $__errorArgs = ['packing_list_pdf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="bl_pdf">Bill of Lading (PDF)</label>
                <?php if($import->bl_pdf): ?>
                    <div><a href="<?php echo e(route('imports.view', [$import->id, 'bl_pdf'])); ?>" class="file-link" target="_blank"><i class="bi bi-file-pdf me-1"></i>Ver PDF actual</a></div>
                <?php endif; ?>
                <input type="file" name="bl_pdf" id="bl_pdf" class="<?php $__errorArgs = ['bl_pdf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" accept="application/pdf" style="margin-top: 8px;" />
                <?php $__errorArgs = ['bl_pdf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="apostillamiento_pdf">Apostillamiento (PDF)</label>
                <?php if($import->apostillamiento_pdf): ?>
                    <div><a href="<?php echo e(route('imports.view', [$import->id, 'apostillamiento_pdf'])); ?>" class="file-link" target="_blank"><i class="bi bi-file-pdf me-1"></i>Ver PDF actual</a></div>
                <?php endif; ?>
                <input type="file" name="apostillamiento_pdf" id="apostillamiento_pdf" class="<?php $__errorArgs = ['apostillamiento_pdf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" accept="application/pdf" style="margin-top: 8px;" />
                <?php $__errorArgs = ['apostillamiento_pdf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="etd">ETD</label>
                <input type="text" name="etd" id="etd" class="<?php $__errorArgs = ['etd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('etd', $import->etd)); ?>" />
                <?php $__errorArgs = ['etd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="shipping_company">Naviera o Agente de Carga</label>
                <input type="text" name="shipping_company" id="shipping_company" class="<?php $__errorArgs = ['shipping_company'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('shipping_company', $import->shipping_company)); ?>" />
                <?php $__errorArgs = ['shipping_company'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="free_days_at_dest">Días libres destino</label>
                <input type="number" name="free_days_at_dest" id="free_days_at_dest" class="<?php $__errorArgs = ['free_days_at_dest'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" min="0" value="<?php echo e(old('free_days_at_dest', $import->free_days_at_dest)); ?>" />
                <?php $__errorArgs = ['free_days_at_dest'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="supplier">Proveedor</label>
                <input type="text" name="supplier" id="supplier" class="<?php $__errorArgs = ['supplier'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('supplier', $import->supplier)); ?>" />
                <?php $__errorArgs = ['supplier'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="credit_time">Tiempo de crédito *</label>
                <select name="credit_time" id="credit_time" class="<?php $__errorArgs = ['credit_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                    <option value="15" <?php echo e(old('credit_time', $import->credit_time) == '15' ? 'selected' : ''); ?>>15 días</option>
                    <option value="30" <?php echo e(old('credit_time', $import->credit_time) == '30' ? 'selected' : ''); ?>>30 días</option>
                    <option value="45" <?php echo e(old('credit_time', $import->credit_time) == '45' ? 'selected' : ''); ?>>45 días</option>
                </select>
                <?php $__errorArgs = ['credit_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="actions">
                <a href="<?php echo e(route('imports.provider-index')); ?>" class="btn-cancel">Cancelar</a>
                <button type="submit" class="btn-save">Actualizar</button>
            </div>
        </form>
    </div>
</div>
<script>
document.addEventListener('DOMContentLoaded', function() {
    let containerCount = <?php echo e($import->containers ? $import->containers->count() : 1); ?>;
    const containersContainer = document.getElementById('containers-container');
    const addContainerBtn = document.getElementById('add-container-btn');
    
    addContainerBtn.addEventListener('click', function() {
        const containerHtml = `
            <div class="container-item" style="border: 1px solid #ddd; border-radius: 8px; padding: 15px; margin-bottom: 15px; background: #f9f9f9;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                    <strong style="color: #333;">Contenedor #${containerCount + 1}</strong>
                    <button type="button" class="btn-remove-container" style="background: #dc3545; color: white; border: none; padding: 4px 10px; border-radius: 4px; cursor: pointer; font-size: 12px;">Eliminar</button>
                </div>
                <div class="form-group" style="margin-bottom: 12px;">
                    <label style="font-size: 13px; margin-bottom: 4px;">Referencia *</label>
                    <input type="text" name="containers[${containerCount}][reference]" class="form-control" style="padding: 8px 12px; font-size: 14px;" required />
                </div>
                <div class="form-group" style="margin-bottom: 12px;">
                    <label style="font-size: 13px; margin-bottom: 4px;">PDF</label>
                    <input type="file" name="containers[${containerCount}][pdf]" class="form-control" style="padding: 6px; font-size: 13px;" accept="application/pdf" />
                </div>
                <div class="form-group" style="margin-bottom: 0;">
                    <label style="font-size: 13px; margin-bottom: 4px;">Imágenes</label>
                    <input type="file" name="containers[${containerCount}][images][]" class="form-control" style="padding: 6px; font-size: 13px;" accept="image/png,image/jpeg" multiple />
                </div>
            </div>
        `;
        containersContainer.insertAdjacentHTML('beforeend', containerHtml);
        containerCount++;
        updateRemoveButtons();
    });
    
    function updateRemoveButtons() {
        const containerItems = containersContainer.querySelectorAll('.container-item');
        containerItems.forEach((item, index) => {
            const removeBtn = item.querySelector('.btn-remove-container');
            if (containerItems.length > 1) {
                removeBtn.style.display = 'block';
                removeBtn.addEventListener('click', function() {
                    item.remove();
                    updateRemoveButtons();
                    // Renumerar contenedores
                    const remainingItems = containersContainer.querySelectorAll('.container-item');
                    remainingItems.forEach((itm, idx) => {
                        itm.querySelector('strong').textContent = `Contenedor #${idx + 1}`;
                    });
                });
            } else {
                removeBtn.style.display = 'none';
            }
        });
    }
    
    updateRemoveButtons();
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\easyInventory\resources\views/imports/edit.blade.php ENDPATH**/ ?>