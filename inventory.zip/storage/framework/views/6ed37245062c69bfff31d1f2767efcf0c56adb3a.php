

<?php $__env->startSection('content'); ?>
<style>
.table-users { width:100%; border-collapse:collapse; background:white; border-radius:10px; overflow:hidden; box-shadow:0 4px 10px rgba(0,0,0,0.08); }
.table-users th { background:#0d6efd; color:white; text-align:left; padding:12px; font-size:15px; }
.table-users td { padding:12px; border-bottom:1px solid #ebebeb; }
.table-users tr:hover { background:#f2f8ff; }
.actions button,.actions a{ padding:6px 12px; border:none; border-radius:6px; cursor:pointer; font-size:13px; margin-right:6px; text-decoration:none; }
.btn-edit{background:#198754;color:white;}
.btn-delete{background:#ffc107;color:#b30000;}
</style>
<div class="container-fluid" style="padding-top:32px;min-height:88vh;">
    <div class="mx-auto" style="max-width:1050px;">
    <?php if(auth()->user()->rol === 'admin'): ?>
    <div class="d-flex justify-content-end align-items-center mb-3"><a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary rounded-pill px-4" style="font-weight:500;"><i class="bi bi-person-plus me-2"></i>Nuevo usuario</a></div>
    <?php endif; ?>
    <h2 class="mb-4 text-center" style="color:#333;font-weight:bold">Gestión de Usuarios</h2>
    <table class="table-users">
        <thead>
            <tr>
                <th>Nombre completo</th>
                <th>Correo</th>
                <th>Teléfono</th>
                <th>Almacén</th>
                <th>Rol</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($user->nombre_completo); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td><?php echo e($user->telefono ?? '-'); ?></td>
                <td><?php echo e($user->almacen->nombre ?? '-'); ?></td>
                <td><?php echo e(ucfirst($user->rol)); ?></td>
                <td class="actions">
                    <a href="<?php echo e(route('users.edit', $user)); ?>" class="btn-edit">Editar</a>
                    <?php if(auth()->user()->rol === 'admin' && auth()->id() !== $user->id): ?>
                    <form action="<?php echo e(route('users.destroy', $user)); ?>" method="POST" style="display:inline">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn-delete">Eliminar</button>
                    </form>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="6" class="text-center text-muted py-5"><i class="bi bi-people text-secondary" style="font-size:2.2em;"></i><br><div class="mt-2">No hay usuarios registrados.</div></td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\easyInventory\resources\views/users/index.blade.php ENDPATH**/ ?>