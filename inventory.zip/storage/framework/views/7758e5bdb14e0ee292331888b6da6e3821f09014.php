<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>VIDRIOS J&P S.A.S. | Dashboard</title>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@400;600;700&display=swap" rel="stylesheet">
    <!-- Bootstrap 5 CSS -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            background-color: #ecf0f5;
            font-family: 'Source Sans Pro', Arial, sans-serif;
        }
        .main-sidebar {
            width: 210px;
            background: #222d32;
            position: fixed;
            left: 0;
            top: 0;
            bottom: 0;
            color: #fff;
            z-index: 1040;
            box-shadow: 2px 0 15px -8px #232d3255;
        }
        .sidebar-logo {
            font-size: 1.3rem;
            font-weight: 700;
            padding: 16px 18px 8px 22px;
            display: flex;
            align-items: center;
            gap: 8px;
            color: #fff;
            letter-spacing: .5px;
        }
        .sidebar-logo i {
            font-size: 1.27em;
            margin-right: 2px;
        }
        .sidebar-menu {
            list-style: none;
            padding-left: 0;
            margin: 8px 0 0 0;
        }
        .sidebar-menu li {
            margin-bottom: 2px;
        }
        .sidebar-menu .nav-link {
            color: #b8c7ce;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 13px;
            padding: 8px 15px 8px 28px;
            border-left: 3px solid transparent;
            border-radius: 2px;
            font-size: 1.01em;
            transition: background 0.16s, border-color 0.15s, color 0.14s;
        }
        .sidebar-menu .nav-link.active, .sidebar-menu .nav-link:hover {
            background: #1e282c;
            color: #fff;
            border-left: 3px solid #3c8dbc;
        }
        .main-header {
            position: fixed;
            left: 210px;
            top: 0;
            right: 0;
            height: 60px;
            background: #3c8dbc;
            color: #fff;
            border-bottom: 1px solid #31708f;
            display: flex;
            align-items: center;
            z-index: 1035;
            box-shadow: 0 2px 11px -8px #222d3233;
            padding: 0 24px;
        }
        .main-header .page-title {
            font-size: 1.1rem;
            font-weight: 500;
            margin: 0;
            color: #fff;
            letter-spacing: 0.03em;
        }
        .main-header .user {
            margin-left: auto;
            color: #fff;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .language-selector {
            position: relative;
            display: inline-block;
        }
        .language-selector-wrapper {
            position: relative;
            display: inline-block;
        }
        .language-selector-trigger {
            background: rgba(255, 255, 255, 0.95);
            border: 1px solid rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            padding: 8px 10px 8px 18px;
            color: #333;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            outline: none;
            min-width: 130px;
            transition: all 0.2s ease;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .language-selector-trigger:hover {
            background: #fff;
            border-color: rgba(0, 0, 0, 0.15);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .language-selector .flag-display {
            display: block;
            width: 24px;
            height: 18px;
            border-radius: 2px;
            overflow: hidden;
            box-shadow: 0 1px 2px rgba(0,0,0,0.1);
            flex-shrink: 0;
        }
        .language-selector .flag-display img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }
        .language-selector .arrow {
            pointer-events: none;
            color: #666;
            font-size: 10px;
            margin-left: auto;
        }
        .language-selector-dropdown {
            position: absolute;
            top: 100%;
            right: 0;
            margin-top: 4px;
            background: #fff;
            border: 1px solid rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            min-width: 130px;
            overflow: hidden;
            display: none;
            z-index: 1001;
        }
        .language-selector-dropdown.show {
            display: block;
        }
        .language-selector-option {
            padding: 10px 12px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 10px;
            transition: background 0.2s ease;
            font-size: 14px;
            color: #333;
        }
        .language-selector-option:hover {
            background: #f5f5f5;
        }
        .language-selector-option .flag-option {
            width: 24px;
            height: 18px;
            border-radius: 2px;
            overflow: hidden;
            flex-shrink: 0;
        }
        .language-selector-option .flag-option img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }
        .language-selector select {
            display: none;
        }
        .content-area {
            margin-left: 210px;
            margin-top: 54px;
            min-height: calc(100vh - 105px);
            padding: 30px 18px 20px 18px;
        }
        .main-footer {
            background: #fff;
            border-top: 1px solid #e4e8ed;
            color: #666;
            text-align: right;
            padding: 10px 24px;
            font-size: .99em;
            position: fixed;
            left: 210px;
            right: 0;
            bottom: 0;
            z-index: 1031;
        }
        /* === ESTILO ADMINLTE small-box === */
        .small-box {
            border-radius: 2px;
            position: relative;
            display: block;
            margin-bottom: 20px;
            box-shadow: 0 1px 1px rgba(0, 0, 0, 0.1);
        }
        .small-box > .inner {
            padding: 10px;
        }
        .small-box > .small-box-footer {
            position: relative;
            text-align: center;
            padding: 3px 0;
            color: #fff;
            color: rgba(255, 255, 255, 0.8);
            display: block;
            z-index: 10;
            background: rgba(0, 0, 0, 0.1);
            text-decoration: none;
        }
        .small-box > .small-box-footer:hover {
            color: #fff;
            background: rgba(0, 0, 0, 0.15);
        }
        .small-box h3 {
            font-size: 38px;
            font-weight: bold;
            margin: 0 0 10px 0;
            white-space: nowrap;
            padding: 0;
        }
        .small-box p {
            font-size: 15px;
        }
        .small-box .icon {
            -webkit-transition: all 0.3s linear;
            -o-transition: all 0.3s linear;
            transition: all 0.3s linear;
            position: absolute;
            top: -10px;
            right: 10px;
            z-index: 0;
            font-size: 90px;
            color: rgba(0, 0, 0, 0.15);
        }
        .small-box:hover {
            text-decoration: none;
            color: #f9f9f9;
        }
        .small-box:hover .icon {
            font-size: 95px;
        }
        @media (max-width: 767px) {
            .small-box {
                text-align: center;
            }
            .small-box .icon {
                display: none;
            }
            .small-box p {
                font-size: 12px;
            }
        }
        .sidebar-toggle-btn {
            display: none;
            position: fixed;
            top: 10px;
            left: 10px;
            background: #3c8dbc;
            border: none;
            color: #fff;
            font-size: 25px;
            padding: 6px 10px;
            border-radius: 3px;
            z-index: 3080;
            height: 39px;
            width: 43px;
            align-items: center;
            justify-content: center;
            box-shadow: 2px 3px 6px -6px #222c;
        }
        @media (max-width: 991px) {
            .main-sidebar { left: -240px!important; transition: left 0.3s; }
            .main-sidebar.active { left:0!important; }
            .sidebar-toggle-btn { display:block !important; }
            .main-header { left: 0 !important; padding-left: 48px !important; z-index: 3075; }
            .main-header .page-title {
                font-size: 1.02em;
                max-width: 70vw;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
                display: inline-block;
                vertical-align: middle;
                text-align: center!important;
                margin: 12px auto 3px auto !important;
            }
            .main-header .user { margin-left: 6px; font-size: 0.98em; }
            .content-area { padding: 16px 2vw 18px 2vw !important; margin-top: 58px !important; margin-left: 0 !important; min-width: 0; width: 100vw; }
            .container, .container-fluid { margin: 0 auto; padding: 0 !important; max-width: 100vw; }
            .small-box { width: 100%; margin-bottom: 16px; }
            h2, .page-title { text-align: center !important; margin: 12px auto 3px auto !important; }
        }
        /* Footer siempre ocupando ancho completo */
        .main-footer {
            width: 100vw !important;
            left: 0 !important;
            right: 0 !important;
            position: fixed;
            bottom: 0;
            max-width: 100vw !important;
            min-width: 0;
        }
        /* Ajustes de tabla responsiva/móvil - para todas las tablas y celdas */
        @media (max-width: 991px) {
            .table-responsive { width: 100%; overflow-x: auto; }
            .table-responsive table, table.table, .inventory-table, .transfer-table { min-width: 620px; font-size: 15px; }
            .table tbody tr, .inventory-table tbody tr, .transfer-table tbody tr { white-space: nowrap; }
            .actions { white-space: nowrap !important; display: flex !important; flex-direction: row !important; gap: 5px; align-items: center; justify-content: flex-start; }
            .actions form, .actions a, .actions button { display: inline-block !important; margin-bottom: 0 !important; margin-right: 5px !important; }
        }
        @media (max-width: 680px) {
            .table-responsive table, table.table, .inventory-table, .transfer-table { min-width: 570px; font-size: 14px; }
        }
        /* Evita que el boton hamburguesa se mueva. Utiliza z-index extra alto. */
        @media (max-width: 991px) {
            .sidebar-toggle-btn {top: 11px; left:10px; z-index: 3080; position:fixed;}
        }
        @media (max-width: 600px) {
            .main-sidebar { display: none; }
            .main-sidebar.active { display: block!important; left: 0!important; }
            .main-header, .main-footer {padding-left: 4px; padding-right:6px;}
            .content-area { margin:0; padding:5px 2px 15px 2px;}
        }
        @media (max-width: 591px) {
            .btn { font-size: 0.95em !important; padding: 3px 8px !important; min-width: 72px; }
        }
    </style>
</head>
<body>
    <button id="sidebarToggleBtn" class="sidebar-toggle-btn" type="button" style="display:none;"><i class="bi bi-list"></i></button>
    <aside class="main-sidebar">
        <div class="sidebar-logo">
    <img src="<?php echo e(asset('public/logo.png')); ?>" alt="Logo" style="width:36px;height:36px;object-fit:contain;">
    <span style="display:flex;flex-direction:column;line-height:1.13;">
        <span style="font-weight:bold;font-size:1em;">VIDRIOS J&amp;P S.A.S.</span>
        <span style="font-size:11px;font-weight:500;margin-top:1px;color:#cfd8dc;">NIT: 901.701.161-4</span>
    </span>
</div>
        <ul class="sidebar-menu">
            <?php
                $user = Auth::user();
                $ID_PABLO_ROJAS = 1;
                $isPabloRojas = $user && ($user->rol === 'admin' || $user->almacen_id == $ID_PABLO_ROJAS);
                $isFuncionario = $user && $user->rol === 'funcionario';
                $isImporter = $user && $user->rol === 'importer';
            ?>
            <?php if(!$isImporter): ?>
            <li><a class="nav-link <?php echo e(request()->is('/') ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>"><i class="bi bi-bar-chart"></i> <?php echo e(__('common.movimientos')); ?></a></li>
            <li><a class="nav-link" href="<?php echo e(route('products.index')); ?>"><i class="bi bi-bag"></i> <?php echo e(__('common.productos')); ?></a></li>
            <?php if($user && $user->rol === 'admin'): ?>
              <li><a class="nav-link" href="<?php echo e(route('warehouses.index')); ?>"><i class="bi bi-building"></i> <?php echo e(__('common.bodegas')); ?></a></li>
            <?php endif; ?>
            <li><a class="nav-link" href="<?php echo e(route('transfer-orders.index')); ?>"><i class="bi bi-arrow-left-right"></i> <?php echo e(__('common.transferencias')); ?></a></li>
            <li><a class="nav-link" href="<?php echo e(route('salidas.index')); ?>"><i class="bi bi-box-arrow-right"></i> <?php echo e(__('common.salidas')); ?></a></li>
            <?php if($isPabloRojas || $isFuncionario): ?>
            <li><a class="nav-link" href="<?php echo e(route('drivers.index')); ?>"><i class="bi bi-truck"></i> <?php echo e(__('common.conductores')); ?></a></li>
            <li><a class="nav-link" href="<?php echo e(route('containers.index')); ?>"><i class="bi bi-box"></i> <?php echo e(__('common.contenedores')); ?></a></li>
            <?php endif; ?>
            <li><a class="nav-link <?php echo e(request()->routeIs('stock.*') ? 'active' : ''); ?>" href="<?php echo e(route('stock.index')); ?>"><i class="bi bi-clipboard-data"></i> <?php echo e(__('common.stock')); ?></a></li>
            <li><a class="nav-link <?php echo e(request()->routeIs('traceability.*') ? 'active' : ''); ?>" href="<?php echo e(route('traceability.index')); ?>"><i class="bi bi-diagram-3"></i> <?php echo e(__('common.trazabilidad')); ?></a></li>
            <?php endif; ?>
            <?php if($user && in_array($user->rol, ['admin', 'importer', 'funcionario'])): ?>
            <li><a class="nav-link <?php echo e(request()->routeIs('imports.*') || request()->routeIs('my-imports') || request()->routeIs('imports.funcionario-index') ? 'active' : ''); ?>" href="<?php echo e($user->rol === 'admin' ? route('imports.index') : ($user->rol === 'funcionario' ? route('imports.funcionario-index') : route('imports.provider-index'))); ?>"><i class="bi bi-upload"></i> <?php echo e(__('common.importacion')); ?></a></li>
            <?php endif; ?>  
            <?php if($user && $user->rol === 'admin' && !$isImporter): ?>
              <li><a class="nav-link" href="<?php echo e(route('users.index')); ?>"><i class="bi bi-person"></i> <?php echo e(__('common.usuarios')); ?></a></li>
            <?php endif; ?>
        </ul>
    </aside>
    <header class="main-header">
        <span class="page-title"><?php echo e(__('common.panel_inventario')); ?></span>
        <div style="display: flex; align-items: center; gap: 20px; margin-left: auto;">
            <!-- Language Selector -->
            <div class="language-selector">
                <div class="language-selector-wrapper">
                    <select id="languageSelect" style="display: none;">
                        <option value="es" <?php echo e(app()->getLocale() == 'es' ? 'selected' : ''); ?>><?php echo e(__('common.espanol')); ?></option>
                        <option value="en" <?php echo e(app()->getLocale() == 'en' ? 'selected' : ''); ?>><?php echo e(__('common.ingles')); ?></option>
                        <option value="zh" <?php echo e(app()->getLocale() == 'zh' ? 'selected' : ''); ?>><?php echo e(__('common.chino')); ?></option>
                    </select>
                    <div class="language-selector-trigger" id="languageTrigger">
                        <span class="flag-display" id="selectedFlag">
                            <img src="<?php echo e(asset('images/flags/' . (app()->getLocale() == 'es' ? 'colombia' : (app()->getLocale() == 'en' ? 'usa' : 'china')) . '.png')); ?>" alt="Flag" />
                        </span>
                        <span id="languageText"><?php echo e(app()->getLocale() == 'es' ? __('common.espanol') : (app()->getLocale() == 'en' ? __('common.ingles') : __('common.chino'))); ?></span>
                        <span class="arrow">▼</span>
                    </div>
                    <div class="language-selector-dropdown" id="languageDropdown">
                        <div class="language-selector-option" data-value="es">
                            <span class="flag-option"><img src="<?php echo e(asset('images/flags/colombia.png')); ?>" alt="Colombia" /></span>
                            <span><?php echo e(__('common.espanol')); ?></span>
                        </div>
                        <div class="language-selector-option" data-value="en">
                            <span class="flag-option"><img src="<?php echo e(asset('images/flags/usa.png')); ?>" alt="USA" /></span>
                            <span><?php echo e(__('common.ingles')); ?></span>
                        </div>
                        <div class="language-selector-option" data-value="zh">
                            <span class="flag-option"><img src="<?php echo e(asset('images/flags/china.png')); ?>" alt="China" /></span>
                            <span><?php echo e(__('common.chino')); ?></span>
                        </div>
                    </div>
                </div>
            </div>
            <span class="user">
              <?php echo e(Auth::user()->name ?? __('common.usuario')); ?> <i class="bi bi-person-circle"></i>
              <form method="POST" action="<?php echo e(route('logout')); ?>" style="display:inline">
                  <?php echo csrf_field(); ?>
                  <button type="submit" title="<?php echo e(__('common.cerrar_sesion')); ?>" style="background:transparent;padding:0 0 0 8px;border:none;color:#fff;cursor:pointer;vertical-align:middle;font-size:19px;margin-left:5px;">
                    <i class="bi bi-box-arrow-right"></i>
                  </button>
              </form>
            </span>
        </div>
    </header>
    <main class="content-area">
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <footer class="main-footer">
        <div><span class="text-muted">&copy; 2026 VIDRIOS J&P S.A.S.</span> <span class="ms-3 text-muted">v1.0.0</span></div>
    </footer>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <?php echo $__env->yieldContent('scripts'); ?>
    <script>
        // Language selector functionality
        document.addEventListener('DOMContentLoaded', function() {
            const trigger = document.getElementById('languageTrigger');
            const dropdown = document.getElementById('languageDropdown');
            const select = document.getElementById('languageSelect');
            const selectedFlag = document.getElementById('selectedFlag');
            const languageText = document.getElementById('languageText');
            const options = dropdown.querySelectorAll('.language-selector-option');
            
            const flagFiles = { 
                'es': '<?php echo e(asset("images/flags/colombia.png")); ?>', 
                'en': '<?php echo e(asset("images/flags/usa.png")); ?>', 
                'zh': '<?php echo e(asset("images/flags/china.png")); ?>' 
            };
            
            const languageNames = {
                'es': '<?php echo e(__('common.espanol')); ?>',
                'en': '<?php echo e(__('common.ingles')); ?>',
                'zh': '<?php echo e(__('common.chino')); ?>'
            };
            
            // Toggle dropdown
            if (trigger) {
                trigger.addEventListener('click', function(e) {
                    e.stopPropagation();
                    dropdown.classList.toggle('show');
                });
            }
            
            // Cerrar al hacer click fuera
            document.addEventListener('click', function(e) {
                if (trigger && dropdown && !trigger.contains(e.target) && !dropdown.contains(e.target)) {
                    dropdown.classList.remove('show');
                }
            });
            
            // Seleccionar opción
            options.forEach(option => {
                option.addEventListener('click', function() {
                    const value = this.dataset.value;
                    if (select) select.value = value;
                    
                    // Actualizar display
                    const img = selectedFlag.querySelector('img');
                    if (img) {
                        img.src = flagFiles[value] || flagFiles['es'];
                    }
                    if (languageText) {
                        languageText.textContent = languageNames[value] || languageNames['es'];
                    }
                    
                    // Cerrar dropdown
                    dropdown.classList.remove('show');
                    
                    // Cambiar idioma
                    changeLanguage(value);
                });
            });
        });
        
        // Función para cambiar el idioma
        function changeLanguage(locale) {
            const url = '<?php echo e(route("language.switch", ["locale" => "__LOCALE__"])); ?>'.replace('__LOCALE__', locale);
            window.location.href = url;
        }

        // Sidebar mobile toggle
        document.addEventListener('DOMContentLoaded', function() {
            var sidebar = document.querySelector('.main-sidebar');
            var toggleBtn = document.getElementById('sidebarToggleBtn');
            toggleBtn && toggleBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                sidebar.classList.toggle('active');
            });
            document.addEventListener('click', function(e){
                if(window.innerWidth < 992 && sidebar.classList.contains('active')){
                    if(!sidebar.contains(e.target) && e.target!==toggleBtn){ sidebar.classList.remove('active'); }
                }
            });
        });
        // Acomoda tablas en scroll si no son table-responsive y corrige problemas de display
        document.addEventListener('DOMContentLoaded', function() {
            if(window.innerWidth < 992) {
                document.querySelectorAll('table:not(.table-responsive)').forEach(function(tbl) {
                    if(!tbl.closest('.table-responsive')){
                        var wrap=document.createElement('div');
                        wrap.className='table-responsive';
                        tbl.parentNode.insertBefore(wrap,tbl); wrap.appendChild(tbl);
                    }
                });
            }
        });
        
        // Función global para hacer logout
        function doLogout() {
            // Crear un formulario para hacer POST al logout
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = '<?php echo e(route("logout")); ?>';
            
            // Agregar token CSRF
            const csrfToken = document.querySelector('meta[name="csrf-token"]');
            if (csrfToken) {
                const csrfInput = document.createElement('input');
                csrfInput.type = 'hidden';
                csrfInput.name = '_token';
                csrfInput.value = csrfToken.getAttribute('content');
                form.appendChild(csrfInput);
            } else {
                // Si no hay meta tag, buscar el token en el formulario de logout existente
                const existingForm = document.querySelector('form[action*="logout"]');
                if (existingForm) {
                    const existingToken = existingForm.querySelector('input[name="_token"]');
                    if (existingToken) {
                        const csrfInput = document.createElement('input');
                        csrfInput.type = 'hidden';
                        csrfInput.name = '_token';
                        csrfInput.value = existingToken.value;
                        form.appendChild(csrfInput);
                    }
                }
            }
            
            document.body.appendChild(form);
            form.submit();
        }
        
        // Detección de inactividad y logout automático después de 30 minutos
        (function() {
            let inactivityTimer;
            const INACTIVITY_TIME = 30 * 60 * 1000; // 30 minutos en milisegundos
            
            function resetTimer() {
                // Crear un formulario para hacer POST al logout
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = '<?php echo e(route("logout")); ?>';
                
                // Agregar token CSRF
                const csrfToken = document.querySelector('meta[name="csrf-token"]');
                if (csrfToken) {
                    const csrfInput = document.createElement('input');
                    csrfInput.type = 'hidden';
                    csrfInput.name = '_token';
                    csrfInput.value = csrfToken.getAttribute('content');
                    form.appendChild(csrfInput);
                } else {
                    // Si no hay meta tag, buscar el token en el formulario de logout existente
                    const existingForm = document.querySelector('form[action*="logout"]');
                    if (existingForm) {
                        const existingToken = existingForm.querySelector('input[name="_token"]');
                        if (existingToken) {
                            const csrfInput = document.createElement('input');
                            csrfInput.type = 'hidden';
                            csrfInput.name = '_token';
                            csrfInput.value = existingToken.value;
                            form.appendChild(csrfInput);
                        }
                    }
                }
                
                document.body.appendChild(form);
                form.submit();
            }
            
            function resetTimer() {
                clearTimeout(inactivityTimer);
                inactivityTimer = setTimeout(function() {
                    // Hacer logout automático después de 30 minutos de inactividad
                    Swal.fire({
                        icon: 'warning',
                        title: 'Sesión expirada',
                        text: 'Tu sesión ha expirado por inactividad. Serás redirigido al login.',
                        confirmButtonText: 'Aceptar',
                        allowOutsideClick: false,
                        allowEscapeKey: false,
                        showCancelButton: false
                    }).then(function() {
                        doLogout();
                    });
                }, INACTIVITY_TIME);
            }
            
            // Eventos que indican actividad del usuario
            const events = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart', 'click'];
            events.forEach(function(event) {
                document.addEventListener(event, resetTimer, true);
            });
            
            // Iniciar el timer cuando se carga la página
            resetTimer();
        })();
        
        // Interceptar errores 403 y redirigir al login
        document.addEventListener('DOMContentLoaded', function() {
            // Interceptar respuestas AJAX con error 403
            if (window.fetch) {
                const originalFetch = window.fetch;
                window.fetch = function(...args) {
                    return originalFetch.apply(this, args).then(function(response) {
                        if (response.status === 403) {
                            Swal.fire({
                                icon: 'warning',
                                title: 'Sesión expirada',
                                text: 'Tu sesión ha expirado. Serás redirigido al login.',
                                confirmButtonText: 'Aceptar',
                                allowOutsideClick: false,
                                allowEscapeKey: false
                            }).then(function() {
                                doLogout();
                            });
                        }
                        return response;
                    });
                };
            }
        });
    </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\easyInventory\resources\views/layouts/app.blade.php ENDPATH**/ ?>