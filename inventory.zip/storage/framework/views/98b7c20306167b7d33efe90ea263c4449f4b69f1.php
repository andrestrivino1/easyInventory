<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Inventario de Stock</title>
    <style>
        body { font-family: Arial, sans-serif; font-size: 12px; color: #232323; margin: 0 32px; }
        .title { font-size: 20px; font-weight: bold; margin-top: 25px; margin-bottom: 8px; text-align: center; }
        .subtitle { color: #007bff; font-size: 14px; margin-bottom: 18px; text-align: center; }
        .label { color: #666; font-size: 13px; font-weight: bold; }
        table {border-collapse: collapse;width:100%;margin-bottom:25px; page-break-inside: auto;}
        th, td {border: 1px solid #ccc;padding: 6px;text-align: left;font-size:11px;}
        th {background: #edf5ff; font-weight: bold;}
        tr { page-break-inside: avoid; page-break-after: auto; }
        .section-title { font-size: 16px; font-weight: bold; margin-top: 20px; margin-bottom: 10px; color: #0066cc; }
        .footer {margin-top:35px; text-align:right; font-size:13px;color:#777;}
        @media  print {
            body { margin:0; }
            .no-print { display: none !important; }
        }
    </style>
</head>
<body>
    <div style="width:100%;text-align:center;margin-top:14px;margin-bottom:18px;">
        <?php
            $logoPath = public_path('logo.png');
            $logoBase64 = '';
            if (file_exists($logoPath)) {
                $logoData = file_get_contents($logoPath);
                $logoBase64 = 'data:image/png;base64,' . base64_encode($logoData);
            }
        ?>
        <?php if($logoBase64): ?>
            <img src="<?php echo e($logoBase64); ?>" style="max-width:180px;max-height:80px;">
        <?php else: ?>
            <img src="<?php echo e(asset('logo.png')); ?>" style="max-width:180px;max-height:80px;">
        <?php endif; ?>
    </div>
    <div class="title">Inventario de Stock</div>
    <div class="subtitle">Fecha: <?php echo e(date('d/m/Y H:i')); ?></div>
    <?php if($selectedWarehouseId): ?>
        <div class="subtitle">Bodega: <?php echo e($warehouses->where('id', $selectedWarehouseId)->first()->nombre ?? ''); ?></div>
    <?php else: ?>
        <div class="subtitle">Bodega: Todos los bodegas</div>
    <?php endif; ?>

    <!-- Sección de Productos -->
    <div class="section-title">PRODUCTOS</div>
    <table>
        <thead>
            <tr>
                <th>Código</th>
                <th>Nombre</th>
                <th>Bodega</th>
                <th>Medidas</th>
                <th>Contenedor</th>
                <th>Cajas</th>
                <th>Láminas</th>
                <th>Estado</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                // Determinar la bodega a mostrar
                $warehouseIdToShow = null;
                $warehouseName = '-';
                if (isset($product->container_warehouse_id)) {
                    $warehouseIdToShow = $product->container_warehouse_id;
                } elseif ($selectedWarehouseId) {
                    $warehouseIdToShow = $selectedWarehouseId;
                }
                
                if ($warehouseIdToShow) {
                    $warehouse = $warehouses->where('id', $warehouseIdToShow)->first();
                    if ($warehouse) {
                        $warehouseName = $warehouse->nombre . ($warehouse->ciudad ? ' - ' . $warehouse->ciudad : '');
                    }
                } elseif (!$selectedWarehouseId) {
                    $warehouseName = 'Todas';
                }
                
                // Obtener referencia de contenedor
                $containerRef = '-';
                if (isset($product->container_reference)) {
                    $containerRef = $product->container_reference;
                } elseif (isset($productosCantidadesPorContenedor) && $productosCantidadesPorContenedor->has($product->id)) {
                    $cantidadesPorContenedor = $productosCantidadesPorContenedor->get($product->id);
                    $containerRefs = $cantidadesPorContenedor->pluck('container_reference')->unique()->filter()->implode(', ');
                    $containerRef = $containerRefs ?: '-';
                }
                
                // Calcular cajas
                $cajas = '-';
                if (isset($product->cajas_en_contenedor)) {
                    $cajas = number_format($product->cajas_en_contenedor, 0);
                } elseif ($product->tipo_medida === 'caja') {
                    $laminas = isset($product->laminas_en_contenedor) ? $product->laminas_en_contenedor : 0;
                    if ($laminas > 0 && $product->unidades_por_caja > 0) {
                        $cajas = number_format(ceil($laminas / $product->unidades_por_caja), 0);
                    } elseif (isset($productosStockPorBodega) && $productosStockPorBodega->has($product->id)) {
                        $stockPorBodega = $productosStockPorBodega->get($product->id);
                        $stock = $warehouseIdToShow ? $stockPorBodega->get($warehouseIdToShow, 0) : $stockPorBodega->sum();
                        if ($stock > 0 && $product->unidades_por_caja > 0) {
                            $cajas = number_format(ceil($stock / $product->unidades_por_caja), 0);
                        }
                    }
                }
                
                // Calcular láminas
                $laminas = 0;
                if (isset($product->laminas_en_contenedor)) {
                    $laminas = $product->laminas_en_contenedor;
                } elseif (isset($productosStockPorBodega) && $productosStockPorBodega->has($product->id)) {
                    $stockPorBodega = $productosStockPorBodega->get($product->id);
                    if ($warehouseIdToShow) {
                        $laminas = $stockPorBodega->get($warehouseIdToShow, 0);
                    } else {
                        $laminas = $stockPorBodega->sum();
                    }
                }
            ?>
            <tr>
                <td><?php echo e($product->codigo); ?></td>
                <td><?php echo e($product->nombre); ?></td>
                <td><?php echo e($warehouseName); ?></td>
                <td><?php echo e($product->medidas ?? '-'); ?></td>
                <td><?php echo e($containerRef); ?></td>
                <td><?php echo e($cajas); ?></td>
                <td><?php echo e(number_format($laminas, 0)); ?></td>
                <td><?php echo e($product->estado ? 'Activo' : 'Inactivo'); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <!-- Sección de Contenedores -->
    <?php
        $bodegasQueRecibenIds = is_array($bodegasQueRecibenContenedores) ? $bodegasQueRecibenContenedores : [];
    ?>
    <?php if(!$selectedWarehouseId || in_array($selectedWarehouseId, $bodegasQueRecibenIds)): ?>
    <div class="section-title">CONTENEDORES</div>
    <table>
        <thead>
            <tr>
                <th>Referencia</th>
                <th>Bodega</th>
                <th>Productos</th>
                <th>Total Cajas</th>
                <th>Total Láminas</th>
                <th>Observación</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $containers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $container): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $totalBoxes = 0;
                $totalSheets = 0;
                foreach($container->products as $product) {
                    $totalBoxes += $product->pivot->boxes;
                    $totalSheets += ($product->pivot->boxes * $product->pivot->sheets_per_box);
                }
                $warehouseName = '-';
                if ($container->warehouse) {
                    $warehouseName = $container->warehouse->nombre . ($container->warehouse->ciudad ? ' - ' . $container->warehouse->ciudad : '');
                }
            ?>
            <tr>
                <td><strong><?php echo e($container->reference); ?></strong></td>
                <td><?php echo e($warehouseName); ?></td>
                <td>
                    <?php $__currentLoopData = $container->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($product->nombre); ?> (<?php echo e($product->pivot->boxes); ?> cajas × <?php echo e($product->pivot->sheets_per_box); ?> láminas)<?php if(!$loop->last): ?><br><?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td><strong><?php echo e($totalBoxes); ?></strong></td>
                <td><strong><?php echo e(number_format($totalSheets, 0)); ?></strong></td>
                <td><?php echo e($container->note ?? '-'); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php endif; ?>

    <!-- Sección de Transferencias -->
    <div class="section-title">TRANSFERENCIAS</div>
    <table>
        <thead>
            <tr>
                <th>No. Orden</th>
                <th>Origen</th>
                <th>Destino</th>
                <th>Estado</th>
                <th>Fecha</th>
                <th>Productos</th>
                <th>Conductor</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $transferOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transfer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($transfer->order_number); ?></td>
                <td><?php echo e($transfer->from->nombre ?? '-'); ?></td>
                <td><?php echo e($transfer->to->nombre ?? '-'); ?></td>
                <td><?php echo e(ucfirst($transfer->status)); ?></td>
                <td><?php echo e($transfer->date->format('d/m/Y H:i')); ?></td>
                <td>
                    <?php $__currentLoopData = $transfer->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($prod->nombre); ?> (<?php echo e($prod->pivot->quantity); ?> <?php echo e($prod->tipo_medida === 'caja' ? 'cajas' : 'unidades'); ?>)<?php if(!$loop->last): ?><br><?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td><?php echo e($transfer->driver->name ?? '-'); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="footer" style="margin-top:60px; text-align:right; font-size:13px;color:#777;">
        Generado por VIDRIOS J&P S.A.S. - <?php echo e(now()->format('d/m/Y h:i A')); ?>

    </div>
</body>
</html>

<?php /**PATH C:\xampp\htdocs\easyInventory\resources\views/stock/pdf.blade.php ENDPATH**/ ?>