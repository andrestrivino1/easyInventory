

<?php $__env->startSection('content'); ?>
<style>
    .warehouse-table {
        width: 100%;
        border-collapse: collapse;
        background: white;
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.08);
    }
    .warehouse-table th {
        background: #0066cc;
        color: white;
        text-align: left;
        padding: 12px;
        font-size: 15px;
    }
    .warehouse-table td {
        padding: 12px;
        border-bottom: 1px solid #e6e6e6;
    }
    .warehouse-table tr:hover {
        background: #f1f7ff;
    }
    .actions button {
        padding: 6px 12px;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-size: 13px;
        margin-right: 6px;
    }
    .btn-edit {
        background: #1d7ff0;
        color: white;
    }
    .btn-delete {
        background: #ffb3b3;
        color: #b30000;
    }
    .actions button:hover { opacity: 0.85; }
</style>
<div class="container-fluid" style="padding-top:32px; min-height:88vh;">
    <div class="mx-auto" style="max-width:850px;">
      <?php if(session('success') || session('error') || session('warning')): ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
  <?php if(session('success')): ?>
    Swal.fire({
      toast: true,
      position: 'top-end',
      icon: 'success',
      title: '<?php echo e(session('success')); ?>',
      timer: 3300,
      timerProgressBar: true,
      showConfirmButton: false
    });
  <?php endif; ?>
  <?php if(session('error')): ?>
    Swal.fire({
      toast: true,
      position: 'top-end',
      icon: 'error',
      title: '<?php echo e(session('error')); ?>',
      timer: 3500,
      timerProgressBar: true,
      showConfirmButton: false
    });
  <?php endif; ?>
  <?php if(session('warning')): ?>
    Swal.fire({
      toast: true,
      position: 'top-end',
      icon: 'warning',
      title: '<?php echo e(session('warning')); ?>',
      timer: 3300,
      timerProgressBar: true,
      showConfirmButton: false
    });
  <?php endif; ?>
});
</script>
<?php endif; ?>
      <div class="d-flex justify-content-end align-items-center mb-3" style="gap:10px;">
        <a href="<?php echo e(route('warehouses.create')); ?>" class="btn btn-primary rounded-pill px-4" style="font-weight:500;"><i class="bi bi-plus-circle me-2"></i>Nuevo almacén</a>
      </div>
      <h2 class="mb-4" style="text-align:center;color:#333;font-weight:bold;">Almacenes</h2>
      <table class="warehouse-table">
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Dirección</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($warehouse->nombre); ?></td>
                <td><?php echo e($warehouse->direccion ?? '-'); ?></td>
                <td class="actions">
                    <form action="<?php echo e(route('warehouses.edit', $warehouse)); ?>" method="GET" style="display:inline">
                        <button type="submit" class="btn-edit" style="margin-right:7px;">Editar</button>
                    </form>
                    <form action="<?php echo e(route('warehouses.destroy', $warehouse)); ?>" method="POST" style="display:inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn-delete">Eliminar</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="3" class="text-center text-muted py-5">
                  <i class="bi bi-buildings text-secondary" style="font-size:2.2em;"></i><br>
                  <div class="mt-2">No existen almacenes registrados.</div>
                </td>
            </tr>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\easyInventory\resources\views/warehouses/index.blade.php ENDPATH**/ ?>