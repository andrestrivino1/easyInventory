

<?php $__env->startSection('content'); ?>
<style>
    .table-responsive-custom {
        overflow-x: auto;
        max-width: 100vw;
        padding-bottom: 6px;
    }
    .entry-table {
        width: 100%;
        border-collapse: collapse;
        background: white;
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.08);
        font-size: 14px;
        table-layout: auto;
    }
    .entry-table th, .entry-table td {
        padding: 12px;
        word-break: break-word;
        vertical-align: top;
    }
    .entry-table tbody tr:not(:last-child) td {
        border-bottom: 1px solid #e6e6e6;
    }
    .entry-table th {
        background: #0066cc;
        color: white;
        font-size: 14px;
        letter-spacing:0.1px;
        white-space: nowrap;
    }
    .entry-table td {
        font-size: 13.2px;
    }
    .entry-table tr:hover {
        background: #f1f7ff;
    }
    .actions {
        display: flex;
        gap: 6px;
        align-items: center;
        justify-content: center;
        flex-wrap: wrap;
    }
    .actions button, .actions a {
        padding: 5px 9px;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-size: 12px;
        display:inline-block;
        text-decoration:none;
        white-space: nowrap;
    }
    .actions form {
        display: inline-block;
        margin: 0;
    }
    .btn-edit {background: #1d7ff0; color: white;}
    .btn-delete {background: #ffb3b3; color: #b30000;}
    .actions button:hover, .actions a:hover { opacity: 0.85; }
    .entry-table th:nth-child(1) { min-width: 100px; } /* No. Orden */
    .entry-table th:nth-child(2) { min-width: 150px; } /* Contenedor */
    .entry-table th:nth-child(3) { min-width: 120px; } /* Almacén */
    .entry-table th:nth-child(4) { min-width: 100px; } /* Estado */
    .entry-table th:nth-child(5) { min-width: 120px; } /* Fecha */
    .entry-table th:nth-child(6) { min-width: 200px; } /* Producto */
    .entry-table th:nth-child(7) { min-width: 120px; } /* Proveedor */
    .entry-table th:nth-child(8) { min-width: 180px; } /* Acciones */
</style>
<div class="container-fluid" style="padding-top:32px; min-height:88vh;">
    <div class="mx-auto" style="max-width:1400px;">
      <div class="d-flex justify-content-end align-items-center mb-3" style="gap:10px;">
        <a href="<?php echo e(route('container-entry-orders.create')); ?>" class="btn btn-primary rounded-pill px-4" style="font-weight:500;"><i class="bi bi-plus-circle me-2"></i>Nueva orden de entrada</a>
      </div>
      <h2 class="mb-4" style="text-align:center;color:#333;font-weight:bold;">Órdenes de Entrada en Contenedores</h2>
      <div class="table-responsive-custom">
      <table class="entry-table">
        <thead>
            <tr>
                <th>No. Orden</th>
                <th>Contenedor</th>
                <th>Almacén</th>
                <th>Estado</th>
                <th>Fecha</th>
                <th>Producto</th>
                <th>Proveedor</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $entryOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($order->order_number); ?></td>
                <td><?php echo e($order->container->reference ?? '-'); ?></td>
                <td><?php echo e($order->warehouse->nombre ?? '-'); ?></td>
                <td>
                    <?php if($order->status == 'pendiente'): ?>
                      <span style="background:#ffc107;color:#212529;border-radius:5px;padding:3px 10px;font-size:13px;">Pendiente</span>
                    <?php elseif($order->status == 'completado'): ?>
                      <span style="background:#4caf50;color:white;border-radius:5px;padding:3px 10px;font-size:13px;">Completado</span>
                    <?php else: ?>
                      <span style="background:#d1d5db;color:#333;border-radius:5px;padding:3px 10px;font-size:13px;"><?php echo e(ucfirst($order->status)); ?></span>
                    <?php endif; ?>
                </td>
                <td><?php echo e($order->date->setTimezone(config('app.timezone'))->format('d/m/Y H:i')); ?></td>
                <td>
                  <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div style="font-size: 13px; margin-bottom: 4px;">
                      <strong><?php echo e($prod->nombre); ?></strong>
                      <span style="color: #666;">(<?php echo e($prod->pivot->quantity); ?> <?php echo e($prod->tipo_medida === 'caja' ? 'cajas' : 'unidades'); ?>)</span>
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td><?php echo e($order->supplier ?? '-'); ?></td>
                <td class="actions" style="white-space:nowrap;">
                    <?php $user = Auth::user(); ?>
                    <div style="display: flex; gap: 6px; align-items: center; justify-content: center; flex-wrap: wrap;">
                        <?php if($order->status === 'pendiente' && ($user && ($user->rol == 'admin' || $user->almacen_id == $order->warehouse_id))): ?>
                            <a href="<?php echo e(route('container-entry-orders.edit', $order)); ?>" class="btn-edit">Editar</a>
                            <form action="<?php echo e(route('container-entry-orders.destroy', $order)); ?>" method="POST" style="display:inline; margin:0;">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn-delete">Eliminar</button>
                            </form>
                        <?php endif; ?>
                        <a href="<?php echo e(route('container-entry-orders.print', $order)); ?>" class="btn btn-outline-secondary" title="Imprimir" style="padding: 5px 9px; vertical-align:middle;" target="_blank"><i class="bi bi-printer"></i></a>
                    </div>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="8" class="text-center text-muted py-5">
                  <i class="bi bi-inbox text-secondary" style="font-size:2.2em;"></i><br>
                  <div class="mt-2">No existen órdenes de entrada registradas.</div>
                </td>
            </tr>
        <?php endif; ?>
        </tbody>
      </table>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('form[action*="container-entry-orders/"][method="POST"] .btn-delete').forEach(function(btn) {
        btn.closest('form').addEventListener('submit', function(e) {
            e.preventDefault();
            Swal.fire({
                title: '¿Eliminar orden de entrada?',
                text: '¡Esta acción no puede deshacerse!',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Sí, eliminar',
                cancelButtonText: 'Cancelar',
                confirmButtonColor: '#e12d39',
                cancelButtonColor: '#6c757d'
            }).then((result) => {
                if(result.isConfirmed) {
                    e.target.submit();
                }
            });
        });
    });
    // Toast global
    <?php if(session('success')): ?>
    Swal.fire({icon:'success',title:'',text:'<?php echo e(session('success')); ?>',toast:true,position:'top-end',showConfirmButton:false,timer:2900 });
    <?php endif; ?>
    <?php if(session('error')): ?>
    Swal.fire({icon:'error',title:'',text:'<?php echo e(session('error')); ?>',toast:true,position:'top-end',showConfirmButton:false,timer:3500 });
    <?php endif; ?>
});
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\easyInventory\resources\views/container-entry-orders/index.blade.php ENDPATH**/ ?>