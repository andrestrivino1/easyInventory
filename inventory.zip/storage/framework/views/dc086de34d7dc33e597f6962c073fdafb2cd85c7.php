

<?php $__env->startSection('content'); ?>
<style>
    .table-responsive-custom {
        overflow-x: auto;
        max-width: 100vw;
        padding-bottom: 6px;
    }
    .stock-table {
        width: 100%;
        border-collapse: collapse;
        background: white;
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.08);
        font-size: 14px;
        table-layout: auto;
        margin-bottom: 30px;
    }
    .stock-table th, .stock-table td {
        padding: 12px;
        word-break: break-word;
        text-align: center;
        vertical-align: middle;
    }
    .stock-table tbody tr:not(:last-child) td {
        border-bottom: 1px solid #e6e6e6;
    }
    .stock-table th {
        background: #0066cc;
        color: white;
        font-size: 14px;
        letter-spacing: 0.1px;
        white-space: nowrap;
    }
    .stock-table td {
        font-size: 13.2px;
    }
    .stock-table tr:hover {
        background: #f1f7ff;
    }
    .section-title {
        font-size: 18px;
        font-weight: bold;
        color: #333;
        margin-top: 30px;
        margin-bottom: 15px;
        padding-bottom: 8px;
        border-bottom: 2px solid #0066cc;
    }
    .filter-section {
        background: white;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.08);
        margin-bottom: 25px;
    }
    .filter-section label {
        font-weight: bold;
        color: #333;
        margin-right: 10px;
    }
    .filter-section select {
        padding: 8px 15px;
        border: 1px solid #ccc;
        border-radius: 6px;
        font-size: 14px;
        min-width: 200px;
    }
</style>

<div class="container-fluid" style="padding-top:32px; min-height:88vh;">
    <div class="mx-auto" style="max-width:1400px;">
        <h2 class="mb-4" style="text-align:center;color:#333;font-weight:bold;">Inventario de Stock</h2>
        
        <!-- Filtro por almacén y botones de exportación -->
        <div class="filter-section">
            <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
                <?php
                    $user = Auth::user();
                    $isAdmin = $user && $user->rol === 'admin';
                    $isFuncionario = $user && $user->rol === 'funcionario';
                    $isCliente = $user && $user->rol === 'clientes';
                    $canExport = $user && $user->rol === 'admin'; // Solo admin puede descargar
                ?>
                <?php if($isAdmin): ?>
                <form method="GET" action="<?php echo e(route('stock.index')); ?>" style="display: flex; align-items: center; gap: 15px;">
                    <label for="warehouse_id">Filtrar por Bodega:</label>
                    <select name="warehouse_id" id="warehouse_id" onchange="this.form.submit()">
                        <option value="">Todos los bodegas</option>
                        <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($warehouse->id); ?>" <?php echo e($selectedWarehouseId == $warehouse->id ? 'selected' : ''); ?>>
                                <?php echo e($warehouse->nombre); ?><?php echo e($warehouse->ciudad ? ' - ' . $warehouse->ciudad : ''); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </form>
                <?php elseif(($isFuncionario || $isCliente) && $warehouses->count() > 1): ?>
                <form method="GET" action="<?php echo e(route('stock.index')); ?>" style="display: flex; align-items: center; gap: 15px;">
                    <label for="warehouse_id">Filtrar por Bodega:</label>
                    <select name="warehouse_id" id="warehouse_id" onchange="this.form.submit()">
                        <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($warehouse->id); ?>" <?php echo e($selectedWarehouseId == $warehouse->id ? 'selected' : ''); ?>>
                                <?php echo e($warehouse->nombre); ?><?php echo e($warehouse->ciudad ? ' - ' . $warehouse->ciudad : ''); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </form>
                <?php else: ?>
                <div style="display: flex; align-items: center; gap: 15px;">
                    <label>Bodega:</label>
                    <span style="font-weight: 500; color: #333;">
                        <?php if(($isFuncionario || $isCliente) && $warehouses->count() > 0): ?>
                            <?php echo e($warehouses->first()->nombre); ?><?php echo e($warehouses->first()->ciudad ? ' - ' . $warehouses->first()->ciudad : ''); ?>

                        <?php else: ?>
                            <?php echo e($user->almacen->nombre ?? 'N/A'); ?><?php echo e($user->almacen && $user->almacen->ciudad ? ' - ' . $user->almacen->ciudad : ''); ?>

                        <?php endif; ?>
                    </span>
                </div>
                <?php endif; ?>
                <?php if($canExport): ?>
                <div style="display: flex; gap: 10px;">
                    <a href="<?php echo e(route('stock.export-pdf', request()->query())); ?>" class="btn btn-primary" style="padding: 8px 16px; text-decoration: none; border-radius: 6px; font-weight: 500;">
                        <i class="bi bi-file-earmark-pdf me-2"></i>Descargar PDF
                    </a>
                    <a href="<?php echo e(route('stock.export-excel', request()->query())); ?>" class="btn btn-success" style="padding: 8px 16px; text-decoration: none; border-radius: 6px; font-weight: 500; background: #28a745; color: white;">
                        <i class="bi bi-file-earmark-excel me-2"></i>Descargar Excel
                    </a>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Sección de Productos -->
        <div class="section-title">
            <i class="bi bi-box-seam me-2"></i>Productos
            <?php if($selectedWarehouseId): ?>
                <span style="font-size: 14px; font-weight: normal; color: #666;">
                    - <?php echo e($warehouses->where('id', $selectedWarehouseId)->first()->nombre ?? ''); ?>

                </span>
            <?php endif; ?>
        </div>
        <!-- Búsqueda de productos -->
        <div class="mb-3" style="max-width: 400px;">
            <div style="position: relative;">
                <input type="text" id="search-products-stock" class="form-control" placeholder="Buscar productos..." style="padding-left: 40px; border-radius: 25px; border: 2px solid #e0e0e0;">
                <i class="bi bi-search" style="position: absolute; left: 15px; top: 50%; transform: translateY(-50%); color: #999; font-size: 16px;"></i>
            </div>
        </div>
        <div class="table-responsive-custom">
            <table class="stock-table" id="products-stock-table">
                <thead>
                    <tr>
                        <th>Código</th>
                        <th>Nombre</th>
                        <th>Bodega</th>
                        <th>Medidas</th>
                        <th>Contenedor</th>
                        <th>Cajas</th>
                        <th>Laminas</th>
                        <th>Estado</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $bodegasQueRecibenIds = is_array($bodegasQueRecibenContenedores) ? $bodegasQueRecibenContenedores : [];
                        // Si el producto tiene contenedor asignado (siempre que venga de container_product), usar valores del contenedor
                        $productHasContainer = isset($product->container_reference);
                        
                        // Si el producto tiene contenedor asignado, usar valores del contenedor
                        if ($productHasContainer) {
                            $stockEnBodega = $product->laminas_en_contenedor ?? 0;
                            $cajasReales = $product->cajas_en_contenedor ?? 0;
                            $bajoStock = $cajasReales <= 5 && $cajasReales >= 0;
                        } else {
                            // Obtener stock de este producto en la bodega seleccionada (o suma total si no hay bodega seleccionada)
                            $stockEnBodega = 0;
                            if (isset($productosStockPorBodega) && $productosStockPorBodega->has($product->id)) {
                                $stockPorBodega = $productosStockPorBodega->get($product->id);
                                if ($selectedWarehouseId) {
                                    $stockEnBodega = $stockPorBodega->get($selectedWarehouseId, 0);
                                } else {
                                    // Si no hay bodega seleccionada, sumar el stock de todas las bodegas
                                    $stockEnBodega = $stockPorBodega->sum();
                                }
                            }
                            // Calcular cajas para verificar bajo stock
                            $cajasReales = null;
                            $bajoStock = false;
                            if ($product->tipo_medida === 'caja' && $product->unidades_por_caja > 0) {
                                $cajasReales = floor($stockEnBodega / $product->unidades_por_caja);
                                $bajoStock = $cajasReales <= 5 && $cajasReales >= 0; // Bajo stock si tiene 5 o menos cajas
                            }
                        }
                    ?>
                    <tr <?php if($bajoStock): ?> style="background-color: #fff3cd; border-left: 4px solid #ffc107;" <?php endif; ?>>
                        <td><?php echo e($product->codigo); ?></td>
                        <td><strong><?php echo e($product->nombre); ?></strong></td>
                        <td>
                            <?php
                                // Si el producto tiene contenedor asignado, mostrar la bodega del contenedor
                                $warehouseIdToShow = null;
                                if (isset($product->container_warehouse_id)) {
                                    $warehouseIdToShow = $product->container_warehouse_id;
                                } elseif ($selectedWarehouseId) {
                                    $warehouseIdToShow = $selectedWarehouseId;
                                }
                            ?>
                            
                            <?php if($warehouseIdToShow): ?>
                                <?php
                                    $warehouse = $warehouses->where('id', $warehouseIdToShow)->first();
                                ?>
                                <?php if($warehouse): ?>
                                    <span style="font-weight: 500;"><?php echo e($warehouse->nombre); ?><?php echo e($warehouse->ciudad ? ' - ' . $warehouse->ciudad : ''); ?></span>
                                <?php else: ?>
                                    <span style="color: #666; font-style: italic;">-</span>
                                <?php endif; ?>
                            <?php else: ?>
                                <span style="color: #666; font-style: italic;">Todas</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($product->medidas ?? '-'); ?></td>
                        <td>
                            <?php if(isset($product->container_reference)): ?>
                                
                                <span style="font-size: 13px;"><?php echo e($product->container_reference); ?></span>
                            <?php else: ?>
                                <?php
                                    $cantidadesPorContenedor = isset($productosCantidadesPorContenedor) && $productosCantidadesPorContenedor->has($product->id) 
                                        ? $productosCantidadesPorContenedor->get($product->id) 
                                        : collect();
                                ?>
                                <?php if($cantidadesPorContenedor->count() > 0): ?>
                                    <span style="font-size: 13px;"><?php echo e($cantidadesPorContenedor->first()['container_reference'] ?? '-'); ?></span>
                                <?php else: ?>
                                    <span style="color: #999; font-style: italic;">-</span>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if(isset($product->cajas_en_contenedor)): ?>
                                
                                <strong <?php if($product->cajas_en_contenedor <= 5): ?> style="color: #d32f2f; font-weight: bold;" <?php endif; ?>>
                                    <?php echo e(number_format($product->cajas_en_contenedor, 0)); ?> cajas
                                </strong>
                                <?php if($product->cajas_en_contenedor <= 5): ?>
                                    <span style="color: #d32f2f; font-size: 11px; margin-left: 5px;" title="Bajo stock: 5 o menos cajas">⚠️</span>
                                <?php endif; ?>
                            <?php else: ?>
                                <?php if($product->tipo_medida === 'caja' && $cajasReales !== null): ?>
                                    <strong <?php if($bajoStock): ?> style="color: #d32f2f; font-weight: bold;" <?php endif; ?>><?php echo e(number_format($cajasReales, 0)); ?> cajas</strong>
                                    <?php if($bajoStock): ?>
                                        <span style="color: #d32f2f; font-size: 11px; margin-left: 5px;" title="Bajo stock: 5 o menos cajas">⚠️</span>
                                    <?php endif; ?>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if(isset($product->laminas_en_contenedor)): ?>
                                
                                <strong><?php echo e(number_format($product->laminas_en_contenedor, 0)); ?> láminas</strong>
                            <?php else: ?>
                                <strong><?php echo e(number_format($stockEnBodega, 0)); ?> láminas</strong>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($product->estado ? 'Activo' : 'Inactivo'); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" class="text-center text-muted py-4">
                            <i class="bi bi-box text-secondary" style="font-size:2.2em;"></i><br>
                            <div class="mt-2">No hay productos registrados.</div>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Sección de Contenedores -->
        <?php
            $bodegasQueRecibenIds = is_array($bodegasQueRecibenContenedores) ? $bodegasQueRecibenContenedores : [];
        ?>
        <?php if(!$selectedWarehouseId || in_array($selectedWarehouseId, $bodegasQueRecibenIds)): ?>
        <div class="section-title">
            <i class="bi bi-box me-2"></i>Contenedores
            <?php if($selectedWarehouseId): ?>
                <span style="font-size: 14px; font-weight: normal; color: #666;">
                    - <?php echo e($warehouses->where('id', $selectedWarehouseId)->first()->nombre ?? ''); ?>

                </span>
            <?php endif; ?>
        </div>
        <!-- Búsqueda de contenedores -->
        <div class="mb-3" style="max-width: 400px;">
            <div style="position: relative;">
                <input type="text" id="search-containers" class="form-control" placeholder="Buscar contenedores..." style="padding-left: 40px; border-radius: 25px; border: 2px solid #e0e0e0;">
                <i class="bi bi-search" style="position: absolute; left: 15px; top: 50%; transform: translateY(-50%); color: #999; font-size: 16px;"></i>
            </div>
        </div>
        <div class="table-responsive-custom">
            <table class="stock-table" id="containers-table">
                <thead>
                    <tr>
                        <th>Referencia</th>
                        <th>Productos</th>
                        <th>Total Cajas</th>
                        <th>Total Láminas</th>
                        <th>Observación</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $containers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $container): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $totalBoxes = 0;
                        $totalSheets = 0;
                        foreach($container->products as $product) {
                            $totalBoxes += $product->pivot->boxes;
                            $totalSheets += ($product->pivot->boxes * $product->pivot->sheets_per_box);
                        }
                    ?>
                    <tr>
                        <td><strong><?php echo e($container->reference); ?></strong></td>
                        <td>
                            <?php if($container->products->count() > 0): ?>
                                <div style="display: flex; flex-direction: column; gap: 5px;">
                                    <?php $__currentLoopData = $container->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div style="font-size: 13px; line-height: 1.5;">
                                            <strong><?php echo e($product->nombre); ?></strong>
                                            <?php if($product->medidas): ?>
                                                <span style="color: #666; font-weight: normal;">- <?php echo e($product->medidas); ?></span>
                                            <?php endif; ?>
                                            <span style="color: #666;">(<?php echo e($product->pivot->boxes); ?> cajas × <?php echo e($product->pivot->sheets_per_box); ?> láminas)</span>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php else: ?>
                                <span style="color: #999; font-style: italic;">Sin productos</span>
                            <?php endif; ?>
                        </td>
                        <td><strong><?php echo e($totalBoxes); ?></strong></td>
                        <td><strong><?php echo e(number_format($totalSheets, 0)); ?></strong></td>
                        <td><?php echo e($container->note ?? '-'); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center text-muted py-4">
                            <i class="bi bi-box text-secondary" style="font-size:2.2em;"></i><br>
                            <div class="mt-2">No hay contenedores registrados.</div>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>

        <!-- Sección de Transferencias -->
        <div class="section-title">
            <i class="bi bi-arrow-left-right me-2"></i>Transferencias
            <?php if($selectedWarehouseId): ?>
                <span style="font-size: 14px; font-weight: normal; color: #666;">
                    - <?php echo e($warehouses->where('id', $selectedWarehouseId)->first()->nombre ?? ''); ?>

                </span>
            <?php endif; ?>
        </div>
        <!-- Búsqueda de transferencias -->
        <div class="mb-3" style="max-width: 400px;">
            <div style="position: relative;">
                <input type="text" id="search-transfers" class="form-control" placeholder="Buscar transferencias..." style="padding-left: 40px; border-radius: 25px; border: 2px solid #e0e0e0;">
                <i class="bi bi-search" style="position: absolute; left: 15px; top: 50%; transform: translateY(-50%); color: #999; font-size: 16px;"></i>
            </div>
        </div>
        <div class="table-responsive-custom">
            <table class="stock-table" id="transfers-table">
                <thead>
                    <tr>
                        <th>No. Orden</th>
                        <th>Origen</th>
                        <th>Destino</th>
                        <th>Estado</th>
                        <th>Fecha</th>
                        <th>Productos</th>
                        <th>Conductor</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $transferOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transfer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($transfer->order_number); ?></td>
                        <td>
                            <?php if($transfer->from): ?>
                                <?php echo e($transfer->from->nombre); ?><?php echo e($transfer->from->ciudad ? ' - ' . $transfer->from->ciudad : ''); ?>

                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($transfer->to): ?>
                                <?php echo e($transfer->to->nombre); ?><?php echo e($transfer->to->ciudad ? ' - ' . $transfer->to->ciudad : ''); ?>

                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($transfer->status == 'en_transito'): ?>
                                <span style="background:#ffc107;color:#212529;border-radius:5px;padding:3px 10px;font-size:13px;">En tránsito</span>
                            <?php elseif($transfer->status == 'recibido'): ?>
                                <span style="background:#4caf50;color:white;border-radius:5px;padding:3px 10px;font-size:13px;">Recibido</span>
                            <?php else: ?>
                                <span style="background:#d1d5db;color:#333;border-radius:5px;padding:3px 10px;font-size:13px;"><?php echo e(ucfirst($transfer->status)); ?></span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($transfer->date->setTimezone(config('app.timezone'))->format('d/m/Y H:i')); ?></td>
                        <td>
                            <?php $__currentLoopData = $transfer->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div style="font-size: 13px; margin-bottom: 4px;">
                                    <strong><?php echo e($prod->nombre); ?></strong>
                                    <span style="color: #666;">(<?php echo e($prod->pivot->quantity); ?> <?php echo e($prod->tipo_medida === 'caja' ? 'cajas' : 'unidades'); ?>)</span>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td><?php echo e($transfer->driver->name ?? '-'); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted py-4">
                            <i class="bi bi-arrow-left-right text-secondary" style="font-size:2.2em;"></i><br>
                            <div class="mt-2">No hay transferencias registradas.</div>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Sección de Salidas -->
        <div class="section-title">
            <i class="bi bi-box-arrow-up-right me-2"></i>Salidas
            <?php if($selectedWarehouseId): ?>
                <span style="font-size: 14px; font-weight: normal; color: #666;">
                    - <?php echo e($warehouses->where('id', $selectedWarehouseId)->first()->nombre ?? ''); ?>

                </span>
            <?php endif; ?>
        </div>
        <!-- Búsqueda de salidas -->
        <div class="mb-3" style="max-width: 400px;">
            <div style="position: relative;">
                <input type="text" id="search-salidas" class="form-control" placeholder="Buscar salidas..." style="padding-left: 40px; border-radius: 25px; border: 2px solid #e0e0e0;">
                <i class="bi bi-search" style="position: absolute; left: 15px; top: 50%; transform: translateY(-50%); color: #999; font-size: 16px;"></i>
            </div>
        </div>
        <div class="table-responsive-custom">
            <table class="stock-table" id="salidas-table">
                <thead>
                    <tr>
                        <th>No. Salida</th>
                        <th>Bodega</th>
                        <th>Fecha</th>
                        <th>A nombre de</th>
                        <th>NIT/Cédula</th>
                        <th>Productos</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $salidas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salida): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($salida->salida_number); ?></td>
                        <td>
                            <?php if($salida->warehouse): ?>
                                <?php echo e($salida->warehouse->nombre); ?><?php echo e($salida->warehouse->ciudad ? ' - ' . $salida->warehouse->ciudad : ''); ?>

                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($salida->fecha->format('d/m/Y')); ?></td>
                        <td><?php echo e($salida->a_nombre_de); ?></td>
                        <td><?php echo e($salida->nit_cedula); ?></td>
                        <td>
                            <?php
                                $bodegasBuenaventuraIds = \App\Models\Warehouse::getBodegasBuenaventuraIds();
                                $isBuenaventura = in_array($salida->warehouse_id, $bodegasBuenaventuraIds);
                            ?>
                            <?php $__currentLoopData = $salida->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div style="font-size: 13px; margin-bottom: 4px;">
                                    <strong><?php echo e($prod->nombre); ?></strong>
                                    <?php if($isBuenaventura && $prod->tipo_medida === 'caja' && $prod->unidades_por_caja > 0): ?>
                                        <?php
                                            $cajas = floor($prod->pivot->quantity / $prod->unidades_por_caja);
                                        ?>
                                        <span style="color: #666;">(<?php echo e($cajas); ?> cajas)</span>
                                    <?php else: ?>
                                        <span style="color: #666;">(<?php echo e($prod->pivot->quantity); ?> láminas)</span>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center text-muted py-4">
                            <i class="bi bi-box-arrow-up-right text-secondary" style="font-size:2.2em;"></i><br>
                            <div class="mt-2">No hay salidas registradas.</div>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<script>
document.addEventListener("DOMContentLoaded", function() {
    // Búsqueda en tabla de productos
    const searchProducts = document.getElementById('search-products-stock');
    const productsTable = document.getElementById('products-stock-table');
    if (searchProducts && productsTable) {
        searchProducts.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase().trim();
            const rows = productsTable.querySelectorAll('tbody tr');
            rows.forEach(function(row) {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(searchTerm) ? '' : 'none';
            });
        });
    }
    
    // Búsqueda en tabla de contenedores
    const searchContainers = document.getElementById('search-containers');
    const containersTable = document.getElementById('containers-table');
    if (searchContainers && containersTable) {
        searchContainers.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase().trim();
            const rows = containersTable.querySelectorAll('tbody tr');
            rows.forEach(function(row) {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(searchTerm) ? '' : 'none';
            });
        });
    }
    
    // Búsqueda en tabla de transferencias
    const searchTransfers = document.getElementById('search-transfers');
    const transfersTable = document.getElementById('transfers-table');
    if (searchTransfers && transfersTable) {
        searchTransfers.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase().trim();
            const rows = transfersTable.querySelectorAll('tbody tr');
            rows.forEach(function(row) {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(searchTerm) ? '' : 'none';
            });
        });
    }
    
    // Búsqueda en tabla de salidas
    const searchSalidas = document.getElementById('search-salidas');
    const salidasTable = document.getElementById('salidas-table');
    if (searchSalidas && salidasTable) {
        searchSalidas.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase().trim();
            const rows = salidasTable.querySelectorAll('tbody tr');
            rows.forEach(function(row) {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(searchTerm) ? '' : 'none';
            });
        });
    }
});
</script>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\easyInventory\resources\views/stock/index.blade.php ENDPATH**/ ?>