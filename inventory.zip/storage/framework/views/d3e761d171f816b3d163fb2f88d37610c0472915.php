<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Trazabilidad de Productos</title>
    <style>
        body { font-family: Arial, sans-serif; font-size: 11px; color: #232323; margin: 0 32px; }
        .title { font-size: 20px; font-weight: bold; margin-top: 25px; margin-bottom: 8px; text-align: center; }
        .subtitle { color: #007bff; font-size: 12px; margin-bottom: 18px; text-align: center; }
        table {border-collapse: collapse;width:100%;margin-bottom:25px; page-break-inside: auto;}
        th, td {border: 1px solid #ccc;padding: 5px;text-align: left;font-size:10px;}
        th {background: #edf5ff; font-weight: bold;}
        tr { page-break-inside: avoid; page-break-after: auto; }
        .badge-entrada { background: #28a745; color: white; padding: 2px 6px; border-radius: 3px; font-size: 9px; }
        .badge-salida { background: #dc3545; color: white; padding: 2px 6px; border-radius: 3px; font-size: 9px; }
        .quantity-positive { color: #28a745; font-weight: bold; }
        .quantity-negative { color: #dc3545; font-weight: bold; }
        .footer {margin-top:35px; text-align:right; font-size:13px;color:#777;}
        @media  print {
            body { margin:0; }
            .no-print { display: none !important; }
        }
    </style>
</head>
<body>
    <div style="width:100%;text-align:center;margin-top:14px;margin-bottom:18px;">
        <img src="<?php echo e((isset($isExport) && $isExport) ? public_path('logo.png') : asset('logo.png')); ?>" style="max-width:180px;max-height:80px;">
    </div>
    <div class="title">Trazabilidad de Productos</div>
    <div class="subtitle">Fecha: <?php echo e(date('d/m/Y H:i')); ?></div>
    <?php if($selectedProductId): ?>
        <div class="subtitle">Producto: <?php echo e($products->where('id', $selectedProductId)->first()->nombre ?? ''); ?></div>
    <?php else: ?>
        <div class="subtitle">Producto: Todos los productos</div>
    <?php endif; ?>
    <?php if($selectedWarehouseId): ?>
        <div class="subtitle">Almacén: <?php echo e($warehouses->where('id', $selectedWarehouseId)->first()->nombre ?? ''); ?></div>
    <?php else: ?>
        <div class="subtitle">Almacén: Todos los almacenes</div>
    <?php endif; ?>
    <?php if($dateFrom || $dateTo): ?>
        <div class="subtitle">
            Rango: <?php echo e($dateFrom ? date('d/m/Y', strtotime($dateFrom)) : 'Inicio'); ?> - 
            <?php echo e($dateTo ? date('d/m/Y', strtotime($dateTo)) : 'Fin'); ?>

        </div>
    <?php endif; ?>

    <table>
        <thead>
            <tr>
                <th>Fecha</th>
                <th>Tipo</th>
                <th>Producto</th>
                <th>Código</th>
                <th>Cantidad</th>
                <th>Almacén</th>
                <th>Referencia</th>
                <th>Tipo Ref.</th>
                <th>Destino</th>
                <th>Observación</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $movements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($movement['date']->format('d/m/Y H:i')); ?></td>
                <td>
                    <?php if($movement['type'] === 'entrada'): ?>
                        <span class="badge-entrada"><?php echo e($movement['type_label']); ?></span>
                    <?php else: ?>
                        <span class="badge-salida"><?php echo e($movement['type_label']); ?></span>
                    <?php endif; ?>
                </td>
                <td><?php echo e($movement['product_name']); ?></td>
                <td><?php echo e($movement['product_code']); ?></td>
                <td class="<?php echo e($movement['quantity'] > 0 ? 'quantity-positive' : 'quantity-negative'); ?>">
                    <?php echo e($movement['quantity'] > 0 ? '+' : ''); ?><?php echo e(number_format($movement['quantity'], 0)); ?>

                </td>
                <td><?php echo e($movement['warehouse_name']); ?></td>
                <td><?php echo e($movement['reference']); ?></td>
                <td><?php echo e($movement['reference_type']); ?></td>
                <td><?php echo e($movement['destination_warehouse'] ?? '-'); ?></td>
                <td><?php echo e($movement['note'] ?? '-'); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="footer" style="margin-top:60px; text-align:right; font-size:13px;color:#777;">
        Generado por EasyInventory - <?php echo e(now()->format('d/m/Y h:i A')); ?>

    </div>
</body>
</html>

<?php /**PATH C:\xampp\htdocs\easyInventory\resources\views/traceability/pdf.blade.php ENDPATH**/ ?>