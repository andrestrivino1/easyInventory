-- ============================================
-- SQL para ejecutar en phpMyAdmin - PRODUCCIÓN
-- Agregar campo driver_id a la tabla salidas
-- ============================================

-- Agregar columna driver_id a la tabla salidas
ALTER TABLE `salidas` 
ADD COLUMN `driver_id` BIGINT UNSIGNED NULL AFTER `user_id`,
ADD CONSTRAINT `salidas_driver_id_foreign` FOREIGN KEY (`driver_id`) REFERENCES `drivers` (`id`) ON DELETE SET NULL;

-- ============================================
-- INSTRUCCIONES:
-- ============================================
-- 1. Abre phpMyAdmin en tu servidor de producción
-- 2. Selecciona la base de datos de tu aplicación
-- 3. Ve a la pestaña "SQL"
-- 4. Copia y pega el SQL de arriba
-- 5. Haz clic en "Continuar" o "Ejecutar"
-- ============================================

